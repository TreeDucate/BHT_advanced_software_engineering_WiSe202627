p = dict()

# -----------------------------------------------------------------------------
# Static datasets (folder "datasets/")
p["geocode"]        = "PLZ"
p["file_plz"]       = "geodata_berlin_plz.csv"
p["file_dis"]       = "geodata_berlin_dis.csv"
p["file_residents"] = "plz_einwohner.csv"
p["file_info"]      = "osm_download_info.json"     # written by download_osm.py

# -----------------------------------------------------------------------------
# OSM data sources. The pull-down menu "Data source" is generated from this dict.
#   tags   : OSM tags used for the download (key: value or key: list of values)
#   file   : csv file in "datasets/" written by download_osm.py
#   subcat : OSM tag used for the dependent pull-down menu "Category filter"
p["sources"] = {
    "Restaurants":       {"tags": {"amenity": "restaurant"},
                          "file": "osm_restaurants.csv",  "subcat": "cuisine"},
    "Cafes":             {"tags": {"amenity": "cafe"},
                          "file": "osm_cafes.csv",        "subcat": "cuisine"},
    "Fast food":         {"tags": {"amenity": "fast_food"},
                          "file": "osm_fast_food.csv",    "subcat": "cuisine"},
    "Pharmacies":        {"tags": {"amenity": "pharmacy"},
                          "file": "osm_pharmacies.csv",   "subcat": "brand"},
    "Supermarkets":      {"tags": {"shop": "supermarket"},
                          "file": "osm_supermarkets.csv", "subcat": "brand"},
    "Playgrounds":       {"tags": {"leisure": "playground"},
                          "file": "osm_playgrounds.csv",  "subcat": "access"},
    "Charging stations": {"tags": {"amenity": "charging_station"},
                          "file": "osm_charging.csv",     "subcat": "operator"},
    # TODO (team): add at least one source of your own choice (at least six sources in total)
}

# -----------------------------------------------------------------------------
# Options of the other pull-down menus
p["areas"]      = {"Postal code (PLZ)": "PLZ", "District (Bezirk)": "Bezirk"}
p["indicators"] = ["Number", "Number per km2", "Number per 10,000 residents"]
p["maptypes"]   = ["Choropleth", "Heatmap", "Point map (clusters)"]
p["colorscales"] = {"Yellow-Red": ["yellow", "red"],
                    "White-Blue": ["white", "darkblue"],
                    "Green-Purple": ["lightgreen", "purple"]}

# -----------------------------------------------------------------------------
# Parameters
p["min_residents"]  = 500       # PLZ areas with fewer residents: no per-resident value
p["top_n_category"] = 10        # number of entries in the category filter
p["dup_distance_m"] = 10        # near-duplicate threshold (quality check)
p["crs_geo"]        = "EPSG:4326"
p["crs_metric"]     = "EPSG:25833"   # ETRS89 / UTM 33N, metres (for area, distance)
p["berlin_lat"]     = (52.3, 52.7)   # plausibility box for coordinates
p["berlin_lon"]     = (13.0, 13.8)

# -----------------------------------------------------------------------------
pdict = p.copy()
